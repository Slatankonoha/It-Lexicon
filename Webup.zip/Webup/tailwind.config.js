/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './public/index.html',
    './public/alphabet.html',
    './public/about.html',
  ],
  theme: {
    fontFamily: {
      'font': ['Noto Sans Thai', 'sans-serif'],
    },
    extend: {
      colors: {
        'gray': '#606060',
        'blue': '#26619C',
        'blue-dark': '#144779',
      },
      spacing: {
        '128': '37.5rem',
        '106': '25rem',
        '136': '42rem',
        '140': '50rem',
      },
      margin: {
        '86': '22rem',
      },
    },
  },
  plugins: [],
} 
// npx tailwindcss -i src/input.css -o public/output.css --watch