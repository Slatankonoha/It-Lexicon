        $(document).ready(function(){

        $("#btn-search").click(function(functionSearch){
                    var text_search = $("#search-box").val();
                    if ($('#search-box').val().length == "0" ){
                       alert("Put some word before search!");
                       return false;
                    }
                    else{
                     $.ajax(
                    {
                       method: "POST", async: false,
                       url: "../db/query.php",
                       data:
                               {
                                fc:"search_keyword",
                                skeyword:text_search
                               },
                        success: function(msg){
                    /*.done(function(msg){*/
                        var container = $('<p/>');
                        var text_search = $("#search-box").val();
                        for (var i = 0; i < msg.length; i++) 
                           {
                            console.log('index: ' + i + ', keyword: ' + msg[i].it_keyword_en + ', meaning: ' + msg[i].meaning_en);
                            container.append('"'+msg[i].it_keyword_en +'"'+ '<br>');
                            container.append(msg[i].it_subject_code + ', ');
                            container.append(msg[i].it_subject_name_en+ ', ' +'<br>');
                            container.append(msg[i].it_course_name_en + ', ');
                            container.append(msg[i].department_name_en + ', ' +'<br>');
                            container.append(msg[i].university_name_en +'<br>'+'<br>');
                            /*add query data to container*/
                           }

                        if(msg.length >= 1){
                        console.log(msg.length);
                        $('#course-id').empty().append(container);
                        $("#s-result-worden").text(msg[0].it_keyword_en);
                        $("#s-result-wordth").text(msg[0].it_keyword_th);
                        $("#re-en").text(msg[0].meaning_en);
                        $("#re-th").text(msg[0].meaning_th);
                        $("#keyword").text('"'+text_search+'"');
                        $('#result-container').show();
                        $('#boxresult').hide();
                        $('#search-box').val('');
                        /*show what found in database*/
                        }

                        else {
                        $('#resulttext').empty().text('Search Result'+' '+'"'+text_search+'"');
                        $("#resulttext1").empty().text("Sorry we don't have the word that you are looking for.");
                        $("#resulttext2").empty().text("Maybe try to search something else?");
                        $('#course-id').empty();
                        $('#result-container').hide();
                        $('#boxresult').show();
                        $('#search-box').val('');
                        /*if no meaning in database*/
                        }
                    }   
                }
                )};
            });
        
        $('#search-box').keypress(function(event){
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if(keycode == '13'){
                var text_search = $("#search-box").val();
                    if ($('#search-box').val().length == "0" ){
                       alert("Put some word before search!");
                       return false;
                    }
                    else{
                     $.ajax(
                    {
                       method: "POST", async: false,
                       url: "../db/query.php",
                       data:
                               {
                                fc:"search_keyword",
                                skeyword:text_search
                               },
                        success: function(msg){
                    /*.done(function(msg){*/
                        var container = $('<p/>');
                        var text_search = $("#search-box").val();
                        for (var i = 0; i < msg.length; i++) 
                           {
                            console.log('index: ' + i + ', keyword: ' + msg[i].it_keyword_en + ', meaning: ' + msg[i].meaning_en);
                            container.append('"'+msg[i].it_keyword_en +'"'+ '<br>');
                            container.append(msg[i].it_subject_code + ' ');
                            container.append(msg[i].it_subject_name_en+'<br>');
                            container.append(msg[i].it_course_name_en + ' ');
                            container.append(msg[i].department_name_en +'<br>');
                            container.append(msg[i].university_name_en +'<br>'+'<br>');
                            /*add query data to container*/
                           }

                        if(msg.length >= 1){
                        console.log(msg.length);
                        $('#course-id').empty().append(container);
                        $("#s-result-worden").text(msg[0].it_keyword_en);
                        $("#s-result-wordth").text(msg[0].it_keyword_th);
                        $("#re-en").text(msg[0].meaning_en);
                        $("#re-th").text(msg[0].meaning_th);
                        $("#keyword").text('"'+text_search+'"');
                        $('#result-container').show();
                        $('#boxresult').hide();
                        $('#search-box').val('');
                        /*show what found in database*/
                        }

                        else {
                        $('#resulttext').empty().text('Search Result'+' '+'"'+text_search+'"');
                        $("#resulttext1").empty().text("Sorry we don't have the word that you are looking for.");
                        $("#resulttext2").empty().text("Maybe try to search something else?");
                        $('#course-id').empty();
                        $('#result-container').hide();
                        $('#boxresult').show();
                        $('#search-box').val('');
                        /*if no meaning in database*/
                        }
                    }   
                }
                )};
            }
        });

        $(function(){
        $('#result-container').hide();
        $('#menu-button').click(function(){
            $('#mobile-menu').toggle();
            });
        $("#totop").on("click", function(){
            // $(window).scrollTop(0,1000);
            $("html, body").animate({ scrollTop: 0 }, "slow");
            return false;
            });
        $('#alpha-terms').click(function(){
            if($('#result-container').hide());

            else if($('#result-container').show())
            $('#result-container').toggle();
            });
        $("#btn-clear").on("click", function(){
            $("#search-box").val('');
            $("#search-box").focus();
            });
        });

        $('.term-click').click(function(){
        var text_search = $(this).text()
        console.log(text_search)
        $.ajax(
            {
               method: "POST", async: false,
               url: "../db/query.php",
               data:
                       {
                        fc:"text_keyword",
                        skeyword:text_search
                       },
                success: function(msg){
                var container = $('<div />');
                var alpha_search = $("#dictionary-term").text();
                for (var i = 0; i < msg.length; i++) 
                   {
                    console.log(msg[i].it_keyword_en);
                    container.append($('<div class="text-blue-dark lg:text-xl text-base my-0.5 hover:font-bold hover:gray" onclick="search_key(\''+msg[i].it_keyword_en+'\')">'+msg[i].it_keyword_en+'</div>'));
                    $(".btext").empty().html(container)
                    $("#alphadis").hide()
                   }
                 }
                });
            });
            });

            
            function search_key(text_search){
                $.ajax(
                    {
                       method: "POST", async: false,
                       url: "../db/query.php",
                       data:
                               {
                                fc:"text_keyword1",
                                skeyword:text_search
                               },
                        success: function(msg){
                        var container = $('<p/>');
                        {
                           console.log(text_search);
                            $("#s-result-worden").empty().text(msg[0].it_keyword_en);
                            $("#s-result-wordth").empty().text(msg[0].it_keyword_th);
                            $("#re-en").empty().text(msg[0].meaning_en);
                            $("#re-th").empty().text(msg[0].meaning_th);
                            $('#result-container').show();
                        }
                        }
                    });
                };