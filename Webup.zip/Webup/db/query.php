<?php
header('Access-Control-Allow-Origin:*');

ini_set('display_errors', 1);
error_reporting(E_ALL);

include_once 'config.php';
$function_name = '';
if (isset($_POST['fc']))
{
    $function_name = $_POST['fc'];
}
else if (isset($_GET['fc']))
{
    $function_name = $_GET['fc'];
}

if ($function_name == "search_keyword")
{
    $skeyword = $_POST['skeyword'];
    $connect = con_a();
    $query = 

	"SELECT
	it_keyword.it_keyword_en, 
	it_keyword.it_keyword_th, 
	it_keyword_meaning_minor.meaning_1_th, 
	it_keyword_meaning_minor.meaning_1_en, 
	it_keyword_meaning_minor.meaning_2_th, 
	it_keyword_meaning_minor.meaning_2_en, 
	it_keyword_meaning.meaning_en, 
	it_keyword_meaning.meaning_th, 
	it_subject.it_subject_code, 
	it_subject.it_subject_name_en, 
	department.department_name_en, 
	university.university_name_en, 
	department.department_name_th, 
	university.university_name_th, 
	it_course.it_course_name_th, 
	it_course.it_course_name_en, 
	it_subject.it_subject_name_th
FROM
	department
	LEFT JOIN
	university
	ON 
		department.university_id = university.university_id
	LEFT JOIN
	it_course
	ON 
		department.department_id = it_course.department_id AND
		university.university_id = it_course.university_id
	LEFT JOIN
	it_subject
	ON 
		it_course.it_course_id = it_subject.it_course_id AND
		department.department_id = it_subject.department_id AND
		university.university_id = it_subject.university_id
	LEFT JOIN
	it_keyword
	ON 
		it_subject.it_subject_id = it_keyword.it_subject_id AND
		it_course.it_course_id = it_keyword.it_course_id AND
		department.department_id = it_keyword.department_id AND
		university.university_id = it_keyword.university_id
	LEFT JOIN
	it_keyword_meaning
	ON 
		it_keyword.it_keyword_id = it_keyword_meaning.it_keyword_id
	LEFT JOIN
	it_keyword_meaning_minor
	ON 
		it_keyword.it_keyword_id = it_keyword_meaning_minor.it_keyword_id
WHERE
	it_keyword.it_keyword_en LIKE '%$skeyword%' OR
	it_keyword.it_keyword_th LIKE '%$skeyword%'";

    include 'json.php';
}

if ($function_name == "text_keyword")
{
    $skeyword = $_POST['skeyword'];
    $connect = con_a();
    $query = 

	"SELECT DISTINCT
	it_keyword.it_keyword_en, 
	it_keyword.it_keyword_th, 
	it_keyword_meaning.meaning_en, 
	it_keyword_meaning.meaning_th, 
	it_keyword_meaning_minor.meaning_1_th, 
	it_keyword_meaning_minor.meaning_1_en, 
	it_keyword_meaning_minor.meaning_2_th, 
	it_keyword_meaning_minor.meaning_2_en
FROM
	it_keyword
	LEFT JOIN
	it_keyword_meaning
	ON 
		it_keyword.it_keyword_id = it_keyword_meaning.it_keyword_id
	LEFT JOIN
	it_keyword_meaning_minor
	ON 
		it_keyword_meaning.it_keyword_id = it_keyword_meaning_minor.it_keyword_id
WHERE
	it_keyword.it_keyword_en LIKE '$skeyword%'"
	;

    include 'json.php';
}

	/*"SELECT
	a.it_keyword_id, 
	b.meaning_id, 
	c.meaning_minor_id, 
	b.meaning_en, 
	b.meaning_th, 
	a.it_keyword_th, 
	a.it_keyword_en
FROM
	it_keyword AS a
	LEFT JOIN
	it_keyword_meaning AS b
	ON 
		a.it_keyword_id = b.meaning_id
	LEFT JOIN
	it_keyword_meaning_minor AS c
	ON 
		a.it_keyword_id = c.meaning_minor_id
WHERE
	a.it_keyword_th LIKE '%$skeyword%'
OR
    a.it_keyword_en LIKE '%$skeyword%'";*/