<?php
$callback = '';
if (isset($_GET['callback']))
{
    $callback = $_GET['callback'];
}

if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
mysqli_set_charset($connect, "utf8");

$result = mysqli_query($connect, $query);
$data = array();

while ($row = mysqli_fetch_assoc($result))
{
    $data[] = $row;
}
if ($callback != null && strlen($callback) > 1)
{
        //echo $callback . "(" . json_encode($data) . ")";
	generate_jsonp($data);
}
else
{
        //echo json_encode($data);
	header('Content-Type: application/json; charset=UTF-8');
	print sprintf('%s', json_encode($data));
}

mysqli_free_result($result);
mysqli_close($connect);
